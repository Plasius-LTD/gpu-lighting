import fs from "node:fs";
import path from "node:path";
import {createHash} from "node:crypto";
import {gunzipSync} from "node:zlib";
import {execFileSync} from "node:child_process";
import assert from "node:assert/strict";
import {createRadialSamplingPlan} from "/Users/philliphounslow/plasius/worktrees/gpu-lighting-adaptive-87/demo/eames-environments/radial-sampling-plan.js";
import {compareLinearImages} from "/Users/philliphounslow/plasius/worktrees/gpu-lighting-adaptive-87/demo/eames-environments/paired-adaptive-metrics.js";
import {compareSamplingRings,assessSamplingExperiment,SAMPLING_EXPERIMENT} from "/Users/philliphounslow/plasius/worktrees/gpu-lighting-adaptive-87/demo/eames-environments/sampler-experiment.js";
const dir=process.argv[2],read=name=>JSON.parse(fs.readFileSync(path.join(dir,name))),sha=b=>createHash("sha256").update(b).digest("hex");
const receipt=read("sampler-summary.json");
assert.equal(receipt.status,"diagnostic-band-screen-passed-not-qualified");assert.deepEqual(receipt.failures,[]);
assert.deepEqual(receipt.lanes.map(l=>l.name),["1080p","4K"]);
assert.equal(receipt.samplingProbe.comparedWords,16384);assert.equal(receipt.samplingProbe.status,"passed");
assert.deepEqual(receipt.protocol,SAMPLING_EXPERIMENT);
const roots={shared:"/Users/philliphounslow/plasius/worktrees/gpu-shared-eames-fidelity",lighting:"/Users/philliphounslow/plasius/worktrees/gpu-lighting-adaptive-87",renderer:"/Users/philliphounslow/plasius/worktrees/gpu-renderer-combined-169",site:"/Users/philliphounslow/plasius/plasius-ltd-site"};
for(const [name,commit] of Object.entries(receipt.provenance.sources))assert.equal(execFileSync("git",["rev-parse",commit],{cwd:roots[name]}).toString().trim(),commit);
for(const file of receipt.scene.manifest.files){
  const bytes=execFileSync("git",["show",receipt.provenance.sources.site+":"+receipt.scene.manifest.sourceDirectory+file.name],{cwd:roots.site,maxBuffer:32*1024*1024});
  assert.equal(bytes.length,file.bytes);assert.equal(sha(bytes),file.sha256);
}
function image(name){
  const r=read(name+".json"),m=r.linearImage,png=fs.readFileSync(path.join(dir,name+".png"));
  assert.equal(png.readUInt32BE(16),r.width);assert.equal(png.readUInt32BE(20),r.height);assert.equal(m.retained,true);
  if(m.identicalTo){const bytes=image(m.identicalTo);assert.equal(sha(bytes),m.sha256);return bytes;}
  const bytes=Buffer.alloc(m.uncompressedBytes);let offset=0;
  for(const record of m.chunks){
    const chunk=read(path.basename(record.artifact.path).replace(/\.png$/,".json")).chunk;
    assert.equal(chunk.byteOffset,offset);assert.equal(chunk.byteLength,record.byteLength);assert.equal(chunk.sha256,record.sha256);
    const planes=gunzipSync(Buffer.from(chunk.data,"base64")),raw=Buffer.alloc(chunk.byteLength),n=raw.length/4;
    assert.equal(planes.length,raw.length);
    for(let p=0;p<4;p++)for(let i=0;i<n;i++)raw[4*i+p]=planes[p*n+i];
    assert.equal(sha(raw),record.sha256);raw.copy(bytes,offset);offset+=raw.length;
  }
  assert.equal(offset,bytes.length);assert.equal(sha(bytes),m.sha256);return bytes;
}
const floats=b=>new Float32Array(b.buffer,b.byteOffset,b.length/4);
const result={status:"verified-diagnostic-not-qualified",capture:receipt.provenance,assetHashesVerified:7,scene:receipt.scene,samplingProbe:receipt.samplingProbe,bandScreen:receipt.bandScreen,lanes:[]};
for(const lane of receipt.lanes){
  assert.equal(lane.diagnostics.length,lane.name==="1080p"?21:3);
  assert.equal(lane.measurements.length,lane.name==="1080p"?18:6);
  assert.equal(lane.warmups.length,lane.name==="1080p"?6:2);
  for(const setup of lane.setups)assert.deepEqual(setup.memory,lane.memory);
  const samplers=lane.name==="1080p"?SAMPLING_EXPERIMENT.samplers:["owen-sobol"],plan=createRadialSamplingPlan(lane.width,lane.height),traces=[];
  assert.equal(sha(plan.budgets),lane.budgets.sha256);
  for(const sampler of samplers){
    const name=lane.name+"-"+sampler+"-seed7",fixed=image(name+"-fixed"),uniform=image(name+"-uniform"),radial=image(name+"-radial");
    assert(fixed.equals(uniform));
    if(sampler==="legacy")assert.equal(sha(fixed),SAMPLING_EXPERIMENT.historicalFixed1080pSha256);
    const d=lane.diagnostics.find(d=>d.sampler===sampler&&d.seed===7&&d.mode==="radial");
    assert.deepEqual(compareLinearImages(floats(radial),floats(fixed)),d.differenceFromFixed32);
    assert.deepEqual(compareSamplingRings(floats(radial),floats(fixed),plan),d.rings);
    for(const mode of ["fixed","radial"]){
      const measured=lane.measurements.filter(d=>d.sampler===sampler&&d.mode===mode);
      assert.equal(measured.length,3);
      assert.equal(lane.warmups.filter(d=>d.sampler===sampler&&d.mode===mode).length,1);
      for(const f of measured){assert.equal(f.seed,7);assert.equal(f.visibilityBefore,"visible");assert.equal(f.visibilityAfter,"visible");assert.equal(f.validationErrors,0);assert.equal(f.tiles.length,lane.tiles);}
      const times=measured.map(f=>f.completedFrameMs);assert.deepEqual(times,lane.timingSummary[sampler][mode].times);
      assert.equal(times.reduce((a,b)=>a+b,0)/3,lane.timingSummary[sampler][mode].meanMs);
    }
  }
  for(const d of lane.diagnostics){
    assert.equal(d.validationErrors,0);assert.equal(d.fused,false);assert.equal(d.tiles.length,lane.tiles);
    let primary=0,secondary=0,segments=0,gpu=0;
    for(const t of d.tiles){
      const r=t.telemetry.rayCounts;assert.equal(r.status,"available");assert.equal(r.observedPrimaryRays,t.expectedPrimaryRays);
      primary+=r.observedPrimaryRays;secondary+=r.secondaryRays;segments+=r.totalPathSegments;
      assert.equal(t.telemetry.timestampQueryStatus,"available");
      const times=t.rawTimestampPair.map(BigInt),span=Number(times[3]-times[0])/1e6;assert(span>=0);assert(Math.abs(span-t.telemetry.totalGpuTimeMs)<1e-8);gpu+=span;
    }
    assert.equal(primary,d.actualSamples);assert.equal(segments,primary+secondary);
    if(d.mode==="radial"){for(const band of plan.bands)assert.equal(d.actualHistogram[band.spp],band.pixels);assert.equal(d.actualSamples,plan.totalSamples);}
    else assert.equal(d.actualSamples,lane.width*lane.height*32);
    traces.push({sampler:d.sampler,seed:d.seed,mode:d.mode,primary,secondary,segments,gpuTileSpanMs:gpu,cpuProfile:d.cpuProfile,imageSha256:d.imageSha256,
      differenceFromFixed32:d.differenceFromFixed32,rings:d.rings,uniformBitIdentical:d.identityPassed});
  }
  if(lane.name==="1080p")assert.deepEqual(assessSamplingExperiment(lane.diagnostics.filter(d=>d.mode==="radial")),receipt.bandScreen);
  result.lanes.push({name:lane.name,width:lane.width,height:lane.height,memory:lane.memory,admission:lane.admission,adapter:lane.adapter,timing:lane.timingSummary,traces});
}
console.log(JSON.stringify(result,null,2));
