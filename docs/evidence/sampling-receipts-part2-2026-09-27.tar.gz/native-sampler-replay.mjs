import http from 'node:http'; import path from 'node:path'; import {execFileSync} from 'node:child_process';
import {createCaptureBridgeServer} from '/Users/philliphounslow/plasius/worktrees/gpu-lighting-adaptive-87/scripts/eames-environments/capture-bridge-server.mjs';
const roots={"shared":"/Users/philliphounslow/plasius/worktrees/gpu-shared-eames-fidelity","lighting":"/Users/philliphounslow/plasius/worktrees/gpu-lighting-adaptive-87","renderer":"/Users/philliphounslow/plasius/worktrees/gpu-renderer-combined-169","site":"/Users/philliphounslow/plasius/plasius-ltd-site"};
const sources={renderer:'82bbd72a1b7af133cf05bc6a9d654ad96ded6811',lighting:'c21b08d76a3320a952259363cde487c8911d9da0',shared:'729f89c7f77fcadb9ee7eeca53fb6daf02865b8e',site:'21d43a9b63722f1ce69175a5a42b53304ee79102'};
const git=(root,...args)=>execFileSync('git',args,{cwd:root,maxBuffer:32*1024*1024});
const bodies=new Map();
for(const [name,prefix,folders] of [['renderer','',['src','tests/fixtures']],['lighting','/lighting',['src','demo/eames-environments','scripts/eames-environments']],['shared','/shared',['src']]]){
for(const file of git(roots[name],'ls-tree','-rz','--name-only',sources[name],...folders).toString().split('\0').filter(p=>/\.(js|mjs|html|json)$/.test(p)))
bodies.set(prefix+'/'+file,git(roots[name],'show',sources[name]+':'+file));}
const manifest=JSON.parse(bodies.get('/lighting/demo/eames-environments/eames-source-manifest.json'));
for(const file of manifest.files)bodies.set('/eames/'+file.name,git(roots.site,'show',sources.site+':'+manifest.sourceDirectory+file.name));
const captureId='native-sampler-'+new Date().toISOString().replaceAll(':','-').replaceAll('.','-');
const bridge=createCaptureBridgeServer();
const types={'.html':'text/html; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.bin':'application/octet-stream','.gltf':'model/gltf+json'};
http.createServer((req,res)=>{const url=new URL(req.url,'http://127.0.0.1:5205');
if(req.method==='POST'&&url.pathname==='/__plasius-capture'){bridge.emit('request',req,res);return;}
if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return;}
const body=url.pathname==='/__provenance'?Buffer.from(JSON.stringify({sources,source:'immutable-git-objects',captureId})):bodies.get(url.pathname);
if(!body){res.writeHead(404);res.end('Not found');return;}
res.writeHead(200,{'Content-Type':url.pathname==='/__provenance'?'application/json':types[path.extname(url.pathname)]??'text/javascript; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:body);
}).listen(5205,'127.0.0.1',()=>console.log(JSON.stringify({port:5205,sources,captureId})));
